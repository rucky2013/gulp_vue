function a(){
    console.log(a);
}
