<template>
    <h1>{{msg}}</h1>
</template>
<script>
export default {
    data () {
        return {
            msg :'hello world'
        }
    }
}
</script>
<style>
h1{
    text-align: center;
}
</style>
