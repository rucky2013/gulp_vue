<template>
    <h1>{{msg}}</h1>
</template>
<script>
export default {
    data () {
        return {
            msg :'hello world'
        }
    }
}
</script>
<style scoped>
h1{
    text-align: center;
    background: url('images/img.jpg');
}
</style>
